import SwiftUI

@main
struct BikeRecorderApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
