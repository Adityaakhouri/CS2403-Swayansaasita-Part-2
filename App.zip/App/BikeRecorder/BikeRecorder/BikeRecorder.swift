import Foundation
import ARKit
import CoreMotion
import CoreLocation
import Network
import Combine
import UIKit

struct RecordingSession: Codable, Identifiable {
    var id          = UUID()
    var name:         String
    var folderPath:   String
    var startTime:    Date
    var duration:     TimeInterval
    var cameraCount:  Int
    var depthFrames:  Int
    var imuSamples:   Int
    var gpsPoints:    Int
}

class BikeRecorder: NSObject, ObservableObject,
                    ARSessionDelegate,
                    CLLocationManagerDelegate {

    var isConnected     = false { didSet { objectWillChange.send() } }
    var isRecording     = false { didSet { objectWillChange.send() } }
    var statusText      = "Enter MacBook IP — tap Connect"
                                  { didSet { objectWillChange.send() } }
    var frameCount      = 0     { didSet { objectWillChange.send() } }
    var depthCount      = 0     { didSet { objectWillChange.send() } }
    var imuCount        = 0     { didSet { objectWillChange.send() } }
    var speedKmh        = 0.0   { didSet { objectWillChange.send() } }
    var macIP           = "192.168.2.1"
                                  { didSet { objectWillChange.send() } }
    var cameraStatus    : [Int: String] = [:]
                                  { didSet { objectWillChange.send() } }
    var sessions        : [RecordingSession] = []
                                  { didSet { objectWillChange.send() } }
    var recordingStart  : Date?   = nil
    var camerasChecked            = false
                                  { didSet { objectWillChange.send() } }
    var connectedCount            = 0
                                  { didSet { objectWillChange.send() } }
    var macBatteryLevel           = -1.0
                                  { didSet { objectWillChange.send() } }
    var macIsCharging             = false
                                  { didSet { objectWillChange.send() } }
    var macHDMI                   = false
                                  { didSet { objectWillChange.send() } }
    var isConnecting              = false
                                  { didSet { objectWillChange.send() } }
    var isStopping                = false
                                  { didSet { objectWillChange.send() } }
    var warnings                  : [String] = []
                                  { didSet { objectWillChange.send() } }

    var allCamerasReady: Bool {
        camerasChecked && connectedCount == 6
    }
    var missingCameras: Int {
        max(0, 6 - connectedCount)
    }

    private var arSession          = ARSession()
    private var motion             = CMMotionManager()
    private var location           = CLLocationManager()
    private var cmdConn            : NWConnection?
    private var depthConn          : NWConnection?
    private var imuConn            : NWConnection?
    private var gpsConn            : NWConnection?
    private var t0                 : Double = 0
    private var lastPath           = ""
    private var connectTimer       : Timer?
    private var heartbeatTimer     : Timer?
    private var statusTimer        : Timer?
    private var heartbeatFailCount = 0
    private var isFetchingStatus   = false
    private var gyroBias           : [Double] = [0, 0, 0]

    private let nameToSlot = [
        "front-left":  0,
        "front-right": 1,
        "side-left":   2,
        "side-right":  3,
        "back-left":   4,
        "back-right":  5
    ]

    // MARK: - Setup
    func setupListeners() {
        location.delegate        = self
        location.desiredAccuracy = kCLLocationAccuracyBest
        location.requestWhenInUseAuthorization()
        location.startUpdatingLocation()
        arSession.delegate = self
        loadSessions()
        if let saved = UserDefaults.standard
            .string(forKey: "macIP") {
            macIP = saved
        }
    }

    // MARK: - Connect
    func connect() {
        guard !isConnecting else { return }
        statusText     = "Connecting..."
        isConnecting   = true
        camerasChecked = false
        connectedCount = 0
        cameraStatus   = [:]
        warnings       = []

        UserDefaults.standard.set(
            macIP, forKey: "macIP")

        connectTimer?.invalidate()
        connectTimer = Timer.scheduledTimer(
            withTimeInterval: 6.0,
            repeats: false) { [weak self] _ in
            guard let self = self else { return }
            DispatchQueue.main.async {
                if self.isConnecting {
                    self.isConnecting = false
                    self.isConnected  = false
                    self.statusText   =
                        "IP address not found — check IP"
                }
            }
        }

        let conn = NWConnection(
            host: NWEndpoint.Host(macIP),
            port: NWEndpoint.Port(rawValue: 9000)!,
            using: .tcp)
        conn.stateUpdateHandler = {
            [weak self] state in
            guard let self = self else { return }
            DispatchQueue.main.async {
                switch state {
                case .ready:
                    self.connectTimer?.invalidate()
                    self.isConnecting = false
                    self.isConnected  = true
                    self.statusText   =
                        "MacBook connected — tap Check cameras"
                    conn.cancel()
                    self.fetchStatus()
                    self.startStatusPolling()
                case .failed:
                    self.connectTimer?.invalidate()
                    self.isConnecting = false
                    self.isConnected  = false
                    self.statusText   =
                        "IP address not found — check IP"
                case .waiting:
                    break
                default:
                    break
                }
            }
        }
        conn.start(queue: .global())
    }

    // MARK: - Status Polling
    func startStatusPolling() {
        statusTimer?.invalidate()
        let interval: TimeInterval =
            isRecording ? 2.0 : 5.0
        statusTimer = Timer.scheduledTimer(
            withTimeInterval: interval,
            repeats: true) { [weak self] _ in
            guard let self = self,
                  self.isConnected else { return }
            self.fetchStatus()
        }
    }

    // MARK: - Fetch Status
    func fetchStatus() {
        guard !isFetchingStatus else { return }
        isFetchingStatus = true

        let conn = NWConnection(
            host: NWEndpoint.Host(macIP),
            port: NWEndpoint.Port(rawValue: 9000)!,
            using: .tcp)
        conn.stateUpdateHandler = {
            [weak self] state in
            guard let self = self else { return }
            if case .ready = state {
                conn.send(
                    content: "STATUS".data(
                        using: .utf8)!,
                    completion: .contentProcessed {
                        _ in
                        conn.receive(
                            minimumIncompleteLength: 4,
                            maximumLength: 4
                        ) { data, _, _, _ in
                            guard let data = data,
                                  data.count == 4
                            else {
                                DispatchQueue.main
                                    .async {
                                    self
                                    .isFetchingStatus
                                        = false
                                }
                                return
                            }
                            let len = Int(UInt32(
                                bigEndian:
                                    data
                                    .withUnsafeBytes {
                                        $0.load(
                                            as: UInt32
                                            .self)
                                    }))
                            conn.receive(
                                minimumIncompleteLength:
                                    len,
                                maximumLength: len
                            ) { data, _, _, _ in
                                defer {
                                    DispatchQueue
                                        .main.async {
                                        self
                                        .isFetchingStatus
                                            = false
                                    }
                                }
                                guard let data = data,
                                      let json =
                                        try?
                                        JSONSerialization
                                        .jsonObject(
                                            with: data)
                                        as?
                                        [String: Any]
                                else { return }
                                DispatchQueue.main
                                    .async {
                                    self.parseStatus(
                                        json)
                                }
                                conn.cancel()
                            }
                        }
                    })
            } else if case .failed = state {
                DispatchQueue.main.async {
                    self.isFetchingStatus = false
                    if self.isRecording {
                        self.addWarning(
                            "⚠️ MacBook unreachable")
                        self.forceStopRecording(
                            reason:
                            "MacBook unreachable")
                    } else if self.isConnected {
                        self.isConnected  = false
                        self.statusText   =
                            "Disconnected — check IP"
                        self.statusTimer?.invalidate()
                    }
                }
            }
        }
        conn.start(queue: .global())
    }

    private func parseStatus(
        _ json: [String: Any]) {
        if let pct = json["battery"] as? Int {
            macBatteryLevel = Double(pct)
        }
        if let charging = json["charging"] as? Bool {
            macIsCharging = charging
        }
        if let hdmi = json["hdmi"] as? Bool {
            let was = macHDMI
            macHDMI = hdmi
            if was && !hdmi && isConnected {
                addWarning(
                    "⚠️ HDMI disconnected — "
                    + "Mac may sleep!")
            }
            if !was && hdmi {
                removeWarning(containing: "HDMI")
            }
        }
        if isRecording,
           let camStatus =
            json["cam_status"]
            as? [String: String] {
            for (name, status) in camStatus {
                if status == "crashed" {
                    if let slot = nameToSlot[name] {
                        if cameraStatus[slot]
                            != "crashed" {
                            cameraStatus[slot] =
                                "crashed"
                            addWarning(
                                "⚠️ \(name) "
                                + "disconnected")
                        }
                    }
                }
            }
        }
    }

    private func addWarning(_ msg: String) {
        if !warnings.contains(msg) {
            warnings.append(msg)
        }
    }

    private func removeWarning(
        containing text: String) {
        warnings.removeAll { $0.contains(text) }
    }

    // MARK: - Disconnect
    func disconnect() {
        connectTimer?.invalidate()
        heartbeatTimer?.invalidate()
        statusTimer?.invalidate()
        isConnected      = false
        isConnecting     = false
        camerasChecked   = false
        connectedCount   = 0
        cameraStatus     = [:]
        macBatteryLevel  = -1.0
        macIsCharging    = false
        macHDMI          = false
        warnings         = []
        isFetchingStatus = false
        depthConn?.cancel()
        imuConn?.cancel()
        gpsConn?.cancel()
        cmdConn?.cancel()
        depthConn = nil
        imuConn   = nil
        gpsConn   = nil
        cmdConn   = nil
        statusText = "Enter MacBook IP — tap Connect"
    }

    // MARK: - Check Cameras
    func checkCameras() {
        statusText     = "Checking cameras..."
        camerasChecked = false
        connectedCount = 0
        cameraStatus   = [:]

        let conn = NWConnection(
            host: NWEndpoint.Host(macIP),
            port: NWEndpoint.Port(rawValue: 9000)!,
            using: .tcp)
        conn.stateUpdateHandler = {
            [weak self] state in
            guard let self = self else { return }
            if case .ready = state {
                conn.send(
                    content: "CHECK".data(
                        using: .utf8)!,
                    completion: .contentProcessed {
                        _ in
                        conn.receive(
                            minimumIncompleteLength: 1,
                            maximumLength: 1024
                        ) { data, _, _, _ in
                            guard let data = data,
                                  let msg = String(
                                    data: data,
                                    encoding: .utf8)
                            else { return }
                            DispatchQueue.main.async {
                                self.parseCameraReply(
                                    msg)
                                conn.cancel()
                            }
                        }
                    })
            } else if case .failed = state {
                DispatchQueue.main.async {
                    self.isConnected = false
                    self.statusText  =
                        "IP address not found — reconnect"
                }
            }
        }
        conn.start(queue: .main)
    }

    private func parseCameraReply(_ msg: String) {
        camerasChecked = true
        var ids:   [Int]    = []
        var names: [String] = []

        for part in msg.components(
            separatedBy: "|") {
            if part.hasPrefix("IDS:") {
                ids = part
                    .replacingOccurrences(
                        of: "IDS:", with: "")
                    .split(separator: ",")
                    .compactMap { Int($0) }
            }
            if part.hasPrefix("NAMES:") {
                names = part
                    .replacingOccurrences(
                        of: "NAMES:", with: "")
                    .split(separator: ",")
                    .map { String($0) }
            }
        }

        cameraStatus = [:]
        for i in 0..<6 {
            cameraStatus[i] = "disconnected"
        }
        for name in names {
            if let slot = nameToSlot[name] {
                cameraStatus[slot] = "connected"
            }
        }
        connectedCount = min(ids.count, 6)

        if connectedCount == 6 {
            statusText = "All 6 cameras connected — ready"
        } else if connectedCount > 0 {
            let missing = 6 - connectedCount
            statusText =
                "\(missing) camera\(missing > 1 ? "s" : "") not connected — check USB"
        } else {
            statusText = "No cameras found on MacBook"
        }
    }

    // MARK: - Heartbeat
    private func startHeartbeat() {
        heartbeatFailCount = 0
        heartbeatTimer?.invalidate()
        heartbeatTimer = Timer.scheduledTimer(
            withTimeInterval: 5.0,
            repeats: true) { [weak self] _ in
            guard let self = self,
                  self.isRecording else { return }
            self.pingMacBook()
        }
    }

    private func pingMacBook() {
        let conn = NWConnection(
            host: NWEndpoint.Host(macIP),
            port: NWEndpoint.Port(rawValue: 9000)!,
            using: .tcp)

        let timer = Timer.scheduledTimer(
            withTimeInterval: 3.0,
            repeats: false) { [weak self] _ in
            guard let self = self else { return }
            conn.cancel()
            DispatchQueue.main.async {
                self.heartbeatFailCount += 1
                if self.heartbeatFailCount >= 2 {
                    self.heartbeatTimer?.invalidate()
                    self.forceStopRecording(
                        reason: "MacBook disconnected")
                }
            }
        }

        conn.stateUpdateHandler = {
            [weak self] state in
            guard let self = self else { return }
            switch state {
            case .ready:
                conn.send(
                    content: "PING".data(
                        using: .utf8)!,
                    completion: .contentProcessed {
                        _ in
                        conn.receive(
                            minimumIncompleteLength: 1,
                            maximumLength: 8
                        ) { data, _, _, _ in
                            timer.invalidate()
                            DispatchQueue.main.async {
                                if data != nil {
                                    self
                                    .heartbeatFailCount
                                        = 0
                                }
                                conn.cancel()
                            }
                        }
                    })
            case .failed:
                timer.invalidate()
                DispatchQueue.main.async {
                    self.heartbeatFailCount += 1
                    if self.heartbeatFailCount >= 2 {
                        self.heartbeatTimer?
                            .invalidate()
                        self.forceStopRecording(
                            reason:
                            "MacBook disconnected")
                    }
                }
            default: break
            }
        }
        conn.start(queue: .global())
    }

    // MARK: - Force Stop
    private func forceStopRecording(
        reason: String) {
        guard isRecording || isStopping
        else { return }
        DispatchQueue.main.async {
            self.isRecording  = false
            self.isStopping   = false
            self.statusText   =
                "⚠️ Stopped: \(reason)"
            self.heartbeatTimer?.invalidate()
            self.statusTimer?.invalidate()
            self.stopSensors()
            self.addWarning(
                "⚠️ Recording stopped: \(reason)")
            for key in self.cameraStatus.keys {
                if self.cameraStatus[key]
                    == "recording" {
                    self.cameraStatus[key] =
                        "connected"
                }
            }
            let dur = self.recordingStart.map {
                Date().timeIntervalSince($0)
            } ?? 0
            let todayCount = self.sessions.filter {
                Calendar.current.isDateInToday(
                    $0.startTime)
            }.count
            let session = RecordingSession(
                name: self.sessionName(
                    index: todayCount + 1) + " ⚠️",
                folderPath:  self.lastPath,
                startTime:
                    self.recordingStart ?? Date(),
                duration:    dur,
                cameraCount: self.connectedCount,
                depthFrames: self.depthCount,
                imuSamples:  self.imuCount,
                gpsPoints:   0)
            self.sessions.insert(session, at: 0)
            self.saveSessions()
            self.depthConn?.cancel()
            self.imuConn?.cancel()
            self.gpsConn?.cancel()
            self.cmdConn?.cancel()
            self.depthConn = nil
            self.imuConn   = nil
            self.gpsConn   = nil
            self.cmdConn   = nil
        }
    }

    // MARK: - Session Name
    private func sessionName(index: Int) -> String {
        let f = DateFormatter()
        f.dateFormat = "dd-MM-yy"
        let dateStr = f.string(from: Date())
        return "\(dateStr)-\(String(format: "%02d", index))"
    }

    // MARK: - Start Recording
    func startEverything() {
        statusText     = "Starting cameras..."
        t0             = Date().timeIntervalSince1970
        recordingStart = Date()
        frameCount     = 0
        depthCount     = 0
        imuCount       = 0
        warnings       = []

        cmdConn = NWConnection(
            host: NWEndpoint.Host(macIP),
            port: NWEndpoint.Port(rawValue: 9000)!,
            using: .tcp)
        cmdConn?.stateUpdateHandler =
            { [weak self] state in
            guard let self = self else { return }
            if case .ready = state {
                let msg = "START:\(self.t0)"
                    .data(using: .utf8)!
                self.cmdConn?.send(
                    content: msg,
                    completion: .contentProcessed {
                        _ in
                        self.waitForReady()
                    })
            } else if case .failed = state {
                DispatchQueue.main.async {
                    self.statusText =
                        "IP address not found"
                }
            }
        }
        cmdConn?.start(queue: .main)

        depthConn = NWConnection(
            host: NWEndpoint.Host(macIP),
            port: NWEndpoint.Port(rawValue: 5000)!,
            using: .tcp)
        depthConn?.stateUpdateHandler = { state in
            if case .ready = state {
                print("Depth TCP connected")
            }
        }
        imuConn = NWConnection(
            host: NWEndpoint.Host(macIP),
            port: NWEndpoint.Port(rawValue: 5001)!,
            using: .udp)
        gpsConn = NWConnection(
            host: NWEndpoint.Host(macIP),
            port: NWEndpoint.Port(rawValue: 5002)!,
            using: .udp)

        depthConn?.start(queue: .global())
        imuConn?.start(queue: .global())
        gpsConn?.start(queue: .global())
    }

    private func waitForReady() {
        cmdConn?.receive(
            minimumIncompleteLength: 1,
            maximumLength: 512
        ) { [weak self] data, _, _, _ in
            guard let self = self,
                  let data = data,
                  let msg  = String(
                    data: data,
                    encoding: .utf8)
            else { return }

            DispatchQueue.main.async {
                guard msg.hasPrefix("READY")
                else { return }

                let parts = msg.components(
                    separatedBy: "|")

                // Extract shared t0 from MacBook
                if let t0Part = parts.first(where: {
                    $0.hasPrefix("READY:") }) {
                    let macT0Str = t0Part
                        .replacingOccurrences(
                            of: "READY:", with: "")
                    if let macT0 = Double(macT0Str) {
                        self.t0 = macT0
                        print("Shared t0: \(macT0)")
                    }
                }

                for part in parts {
                    if part.hasPrefix("PATH:") {
                        self.lastPath = part
                            .replacingOccurrences(
                                of: "PATH:", with: "")
                    }
                    if part.hasPrefix("NAMES:") {
                        let names = part
                            .replacingOccurrences(
                                of: "NAMES:", with: "")
                            .split(separator: ",")
                            .map { String($0) }
                        for name in names {
                            if let slot =
                                self.nameToSlot[name] {
                                self.cameraStatus[slot]
                                    = "recording"
                            }
                        }
                    }
                }

                self.isRecording = true
                self.statusText  =
                    "Calibrating — keep still for 5s..."
                self.startSensors()
                self.startStatusPolling()
            }
        }
    }

    // MARK: - Stop Recording
    func stopEverything() {
        guard isRecording else { return }
        isStopping  = true
        isRecording = false
        heartbeatTimer?.invalidate()
        statusTimer?.invalidate()
        stopSensors()

        DispatchQueue.main.async {
            self.statusText = "Saving — please wait..."
        }

        let timeout = DispatchWorkItem {
            [weak self] in
            guard let self = self,
                  self.isStopping else { return }
            DispatchQueue.main.async {
                self.forceStopRecording(
                    reason: "Save timeout")
            }
        }
        DispatchQueue.main.asyncAfter(
            deadline: .now() + 15,
            execute: timeout)

        let stopConn = NWConnection(
            host: NWEndpoint.Host(macIP),
            port: NWEndpoint.Port(rawValue: 9000)!,
            using: .tcp)
        stopConn.stateUpdateHandler =
            { [weak self] state in
            guard let self = self else { return }
            if case .ready = state {
                stopConn.send(
                    content: "STOP".data(
                        using: .utf8)!,
                    completion: .contentProcessed {
                        _ in
                        stopConn.receive(
                            minimumIncompleteLength: 1,
                            maximumLength: 512
                        ) { data, _, _, _ in
                            timeout.cancel()
                            guard let data = data,
                                  let msg = String(
                                    data: data,
                                    encoding: .utf8)
                            else {
                                DispatchQueue.main
                                    .async {
                                    self
                                    .forceStopRecording(
                                        reason:
                                        "No response")
                                }
                                return
                            }
                            DispatchQueue.main.async {
                                self.finishSession(msg)
                            }
                            stopConn.cancel()
                        }
                    })
            } else if case .failed = state {
                timeout.cancel()
                DispatchQueue.main.async {
                    self.forceStopRecording(
                        reason: "MacBook unreachable")
                }
            }
        }
        stopConn.start(queue: .main)
    }

    private func finishSession(_ msg: String) {
        isStopping  = false
        isRecording = false

        var path  = lastPath
        var depth = depthCount
        var imu   = imuCount
        var gps   = 0

        for part in msg.components(
            separatedBy: "|") {
            if part.hasPrefix("PATH:") {
                path = part.replacingOccurrences(
                    of: "PATH:", with: "")
            }
            if part.hasPrefix("DEPTH:"),
               let n = Int(part.replacingOccurrences(
                of: "DEPTH:", with: "")) {
                depth = n
            }
            if part.hasPrefix("IMU:"),
               let n = Int(part.replacingOccurrences(
                of: "IMU:", with: "")) {
                imu = n
            }
            if part.hasPrefix("GPS:"),
               let n = Int(part.replacingOccurrences(
                of: "GPS:", with: "")) {
                gps = n
            }
        }

        let dur = recordingStart.map {
            Date().timeIntervalSince($0) } ?? 0
        let todayCount = sessions.filter {
            Calendar.current.isDateInToday(
                $0.startTime) }.count

        let session = RecordingSession(
            name:        sessionName(
                index: todayCount + 1),
            folderPath:  path,
            startTime:   recordingStart ?? Date(),
            duration:    dur,
            cameraCount: connectedCount,
            depthFrames: depth,
            imuSamples:  imu,
            gpsPoints:   gps)

        sessions.insert(session, at: 0)
        saveSessions()

        for key in cameraStatus.keys {
            if cameraStatus[key] == "recording" {
                cameraStatus[key] = "connected"
            }
        }
        statusText =
            "Saved ✓ — \(depth) depth, \(imu) IMU"
        frameCount = 0
        depthCount = 0
        imuCount   = 0

        depthConn?.cancel()
        imuConn?.cancel()
        gpsConn?.cancel()
        cmdConn?.cancel()
        depthConn = nil
        imuConn   = nil
        gpsConn   = nil
        cmdConn   = nil

        startStatusPolling()
    }

    // MARK: - IMU Calibration
    private func calibrateIMU(
        completion: @escaping ([Double]) -> Void) {
        var gx: [Double] = []
        var gy: [Double] = []
        var gz: [Double] = []
        let start = Date()
        var calibrationDone = false

        let calibMotion = CMMotionManager()
        calibMotion.deviceMotionUpdateInterval =
            1.0 / 100.0
        calibMotion.startDeviceMotionUpdates(
            to: OperationQueue.main) { data, _ in
            guard let d = data,
                  !calibrationDone else { return }
            if Date().timeIntervalSince(start) < 5.0 {
                gx.append(d.rotationRate.x)
                gy.append(d.rotationRate.y)
                gz.append(d.rotationRate.z)
            } else {
                calibrationDone = true
                calibMotion.stopDeviceMotionUpdates()
                guard !gx.isEmpty else {
                    completion([0, 0, 0])
                    return
                }
                let bx = gx.reduce(0, +)
                    / Double(gx.count)
                let by = gy.reduce(0, +)
                    / Double(gy.count)
                let bz = gz.reduce(0, +)
                    / Double(gz.count)
                let bias = [bx, by, bz]
                print("Gyro bias: \(bias)")
                completion(bias)
            }
        }
    }

    // MARK: - Sensors
    private func startSensors() {
        frameCount = 0
        depthCount = 0
        imuCount   = 0

        UIApplication.shared
            .isIdleTimerDisabled = true

        let config = ARWorldTrackingConfiguration()
        if ARWorldTrackingConfiguration
            .supportsFrameSemantics(.sceneDepth) {
            config.frameSemantics = .sceneDepth
        }
        arSession.run(config)

        // Start IMU immediately
        startIMURecording()

        DispatchQueue.main.async {
            self.statusText =
                "Calibrating — keep still for 5s..."
        }

        calibrateIMU { [weak self] bias in
            guard let self = self else { return }
            self.gyroBias = bias
            DispatchQueue.main.async {
                self.statusText = "Recording..."
            }
            self.startHeartbeat()
        }
    }

    private func startIMURecording() {
        motion.deviceMotionUpdateInterval =
            1.0 / 100.0
        let imuQueue = OperationQueue()
        imuQueue.name = "imu.queue"
        imuQueue.qualityOfService = .userInteractive
        motion.startDeviceMotionUpdates(
            to: imuQueue) { [weak self] data, _ in
            guard let self = self,
                  let d = data,
                  self.isRecording
            else { return }
            self.sendIMU(d)
            DispatchQueue.main.async {
                self.imuCount += 1
            }
        }
    }

    private func stopSensors() {
        UIApplication.shared
            .isIdleTimerDisabled = false
        heartbeatTimer?.invalidate()
        arSession.pause()
        motion.stopDeviceMotionUpdates()
    }

    // MARK: - ARKit Depth
    func session(
        _ session: ARSession,
        didUpdate frame: ARFrame) {
        guard isRecording else { return }

        DispatchQueue.main.async {
            self.frameCount += 1
        }

        guard let depth = frame.sceneDepth,
              let conn  = depthConn
        else { return }

        let ts   = Date().timeIntervalSince1970
        let pose = frame.camera.transform
        var packet = Data()

        var tsVal = ts
        withUnsafeBytes(of: &tsVal) {
            packet.append(contentsOf: $0) }

        for col in 0..<4 {
            for row in 0..<4 {
                var v = pose[col][row]
                withUnsafeBytes(of: &v) {
                    packet.append(contentsOf: $0) }
            }
        }

        let dm = depth.depthMap
        CVPixelBufferLockBaseAddress(dm, .readOnly)
        if let ptr = CVPixelBufferGetBaseAddress(dm) {
            packet.append(Data(
                bytes: ptr,
                count: CVPixelBufferGetDataSize(dm)))
        }
        CVPixelBufferUnlockBaseAddress(dm, .readOnly)

        var length = UInt32(packet.count).bigEndian
        var full   = Data(bytes: &length, count: 4)
        full.append(packet)

        conn.send(
            content: full,
            contentContext: .defaultMessage,
            isComplete: true,
            completion: .contentProcessed { _ in })

        DispatchQueue.main.async {
            self.depthCount += 1
        }
    }

    // MARK: - IMU
    private func sendIMU(_ d: CMDeviceMotion) {
        var packet = Data()
        let vals: [Double] = [
            Date().timeIntervalSince1970,
            d.userAcceleration.x + d.gravity.x,
            d.userAcceleration.y + d.gravity.y,
            d.userAcceleration.z + d.gravity.z,
            d.rotationRate.x - gyroBias[0],
            d.rotationRate.y - gyroBias[1],
            d.rotationRate.z - gyroBias[2],
            d.attitude.roll,
            d.attitude.pitch,
            d.attitude.yaw,
            d.gravity.x,
            d.gravity.y,
            d.gravity.z,
            d.userAcceleration.x,
            d.userAcceleration.y,
            d.userAcceleration.z
        ]
        for var v in vals {
            withUnsafeBytes(of: &v) {
                packet.append(contentsOf: $0) }
        }
        imuConn?.send(
            content: packet,
            completion: .contentProcessed { _ in })
    }

    // MARK: - GPS
    func locationManager(
        _ manager: CLLocationManager,
        didUpdateLocations locs: [CLLocation]) {
        guard let loc = locs.last else { return }

        if isRecording, gpsConn != nil {
            var packet = Data()
            let vals: [Double] = [
                Date().timeIntervalSince1970,
                loc.coordinate.latitude,
                loc.coordinate.longitude,
                loc.altitude,
                loc.speed
            ]
            for var v in vals {
                withUnsafeBytes(of: &v) {
                    packet.append(contentsOf: $0) }
            }
            gpsConn?.send(
                content: packet,
                completion: .contentProcessed {
                    _ in })
        }

        DispatchQueue.main.async {
            self.speedKmh = max(0, loc.speed * 3.6)
        }
    }

    // MARK: - Persistence
    private func sessionsURL() -> URL {
        FileManager.default.urls(
            for: .documentDirectory,
            in: .userDomainMask)[0]
            .appendingPathComponent("sessions.json")
    }

    func saveSessions() {
        if let data = try? JSONEncoder()
            .encode(sessions) {
            try? data.write(to: sessionsURL())
        }
    }

    func loadSessions() {
        guard let data = try? Data(
            contentsOf: sessionsURL()),
              let saved = try? JSONDecoder()
                .decode([RecordingSession].self,
                        from: data)
        else { return }
        sessions = saved
    }
}
