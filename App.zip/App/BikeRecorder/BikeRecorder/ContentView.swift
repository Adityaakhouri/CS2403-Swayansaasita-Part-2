import SwiftUI
import Network

struct ContentView: View {
    @StateObject var recorder = BikeRecorder()
    @State private var selectedTab = 0

    var body: some View {
        ZStack(alignment: .bottom) {
            Color.black.ignoresSafeArea()

            if selectedTab == 0 {
                RecordView(recorder: recorder)
            } else {
                SessionsView(recorder: recorder)
            }

            HStack(spacing: 0) {
                NavTab(
                    icon: "record.circle",
                    label: "Record",
                    selected: selectedTab == 0) {
                    selectedTab = 0
                }
                NavTab(
                    icon: "list.bullet.rectangle",
                    label: "Sessions",
                    selected: selectedTab == 1) {
                    selectedTab = 1
                }
            }
            .background(Color(white: 0.05))
            .overlay(
                Rectangle()
                    .frame(height: 0.5)
                    .foregroundColor(
                        Color(white: 0.15)),
                alignment: .top)
        }
        .onAppear { recorder.setupListeners() }
    }
}

// MARK: - Nav Tab
struct NavTab: View {
    let icon: String
    let label: String
    let selected: Bool
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            VStack(spacing: 3) {
                Image(systemName: icon)
                    .font(.system(size: 20))
                    .foregroundColor(
                        selected ? .blue
                        : Color(white: 0.4))
                Text(label)
                    .font(.system(size: 10))
                    .foregroundColor(
                        selected ? .blue
                        : Color(white: 0.4))
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 8)
        }
    }
}

// MARK: - Record Screen
struct RecordView: View {
    @ObservedObject var recorder: BikeRecorder

    let camNames = [
        "Front-left",  "Front-right",
        "Side-left",   "Side-right",
        "Back-right",  "Back-left"
    ]
    let camPositions = [
        "front-left",  "front-right",
        "side-left",   "side-right",
        "back-right",  "back-left"
    ]

    var recordButtonLabel: String {
        if recorder.isStopping {
            return "Saving files..." }
        if recorder.isRecording {
            return "Stop recording" }
        if recorder.isConnecting {
            return "Connecting..." }
        if !recorder.isConnected {
            return "Not connected" }
        if !recorder.camerasChecked {
            return "Check cameras first" }
        if recorder.allCamerasReady {
            return "Start recording" }
        let m = recorder.missingCameras
        return m > 0
            ? "\(m) camera\(m > 1 ? "s" : "") not connected"
            : "Start recording"
    }

    var recordButtonColor: Color {
        if recorder.isStopping {
            return Color(white: 0.2) }
        if recorder.isRecording { return .red }
        if recorder.allCamerasReady {
            return .green }
        return Color(white: 0.15)
    }

    var body: some View {
        VStack(spacing: 0) {
            ScrollView {
                VStack(spacing: 10) {

                    // Header
                    HStack {
                        Text("BikeRecorder")
                            .font(.system(
                                size: 22,
                                weight: .bold))
                            .foregroundColor(.white)
                        Spacer()
                        StatusBadge(
                            recorder: recorder)
                    }
                    .padding(.top, 12)

                    // Status text
                    Text(recorder.statusText)
                        .font(.system(size: 12))
                        .foregroundColor(
                            Color(white: 0.45))
                        .frame(
                            maxWidth: .infinity,
                            alignment: .leading)

                    // Warnings banner
                    if !recorder.warnings.isEmpty {
                        VStack(spacing: 4) {
                            ForEach(
                                recorder.warnings,
                                id: \.self) { w in
                                HStack(spacing: 6) {
                                    Image(systemName:
                                        "exclamationmark.triangle.fill")
                                        .font(
                                            .system(
                                                size: 11))
                                        .foregroundColor(
                                            .orange)
                                    Text(w)
                                        .font(
                                            .system(
                                                size: 12,
                                                weight:
                                                .medium))
                                        .foregroundColor(
                                            .orange)
                                    Spacer()
                                }
                            }
                        }
                        .padding(.horizontal, 12)
                        .padding(.vertical, 8)
                        .background(Color(
                            red: 0.15,
                            green: 0.08,
                            blue: 0.0))
                        .cornerRadius(9)
                        .overlay(
                            RoundedRectangle(
                                cornerRadius: 9)
                            .stroke(
                                Color.orange
                                    .opacity(0.4),
                                lineWidth: 0.5))
                    }

                    // Sensor cards row 1
                    HStack(spacing: 5) {
                        SensorCard(
                            name: "LiDAR",
                            value:
                                recorder.isRecording
                                ? "Active"
                                : recorder.isConnected
                                ? "Ready" : "Off",
                            color:
                                recorder.isRecording
                                ? .red
                                : recorder.isConnected
                                ? .green : .gray)
                        SensorCard(
                            name: "IMU",
                            value:
                                recorder.isRecording
                                ? "100Hz"
                                : recorder.isConnected
                                ? "Ready" : "Off",
                            color:
                                recorder.isRecording
                                ? .red
                                : recorder.isConnected
                                ? .green : .gray)
                        SensorCard(
                            name: "GPS",
                            value:
                                recorder.isConnected
                                ? "Locked" : "Off",
                            color:
                                recorder.isConnected
                                ? .green : .gray)
                        SensorCard(
                            name: "Speed",
                            value: String(
                                format: "%.0f km/h",
                                recorder.speedKmh),
                            color:
                                recorder.isConnected
                                ? .white : .gray)
                    }

                    // Mac status row
                    HStack(spacing: 5) {
                        SensorCard(
                            name: "Mac Battery",
                            value:
                                recorder
                                .macBatteryLevel >= 0
                                ? "\(Int(recorder.macBatteryLevel))%"
                                  + (recorder
                                     .macIsCharging
                                     ? " ⚡" : "")
                                : "—",
                            color:
                                recorder.macIsCharging
                                ? .blue
                                : recorder
                                .macBatteryLevel > 30
                                ? .green
                                : recorder
                                .macBatteryLevel >= 0
                                ? .red : .gray)
                        SensorCard(
                            name: "HDMI",
                            value:
                                recorder.isConnected
                                ? (recorder.macHDMI
                                   ? "Connected"
                                   : "Not connected")
                                : "—",
                            color:
                                recorder.isConnected
                                ? (recorder.macHDMI
                                   ? .green : .orange)
                                : .gray)
                    }

                    // IP + Connect
                    HStack(spacing: 8) {
                        TextField(
                            "MacBook IP",
                            text: $recorder.macIP)
                            .padding(10)
                            .background(
                                Color(white: 0.1))
                            .cornerRadius(10)
                            .foregroundColor(.white)
                            .font(.system(
                                size: 14,
                                design: .monospaced))
                            .keyboardType(
                                .numbersAndPunctuation)
                            .disabled(
                                recorder.isRecording
                                || recorder
                                .isConnecting)

                        Button(action: {
                            if recorder.isConnected {
                                recorder.disconnect()
                            } else if
                                !recorder.isConnecting {
                                recorder.connect()
                            }
                        }) {
                            Group {
                                if recorder
                                    .isConnecting {
                                    HStack(spacing: 6) {
                                        ProgressView()
                                            .scaleEffect(
                                                0.7)
                                            .tint(.white)
                                        Text(
                                            "Connecting")
                                            .font(
                                                .system(
                                                    size: 13,
                                                    weight:
                                                    .semibold))
                                            .foregroundColor(
                                                Color(
                                                    white:
                                                    0.5))
                                    }
                                } else {
                                    Text(
                                        recorder
                                        .isConnected
                                        ? "Disconnect"
                                        : "Connect")
                                        .font(.system(
                                            size: 13,
                                            weight:
                                            .semibold))
                                        .foregroundColor(
                                            recorder
                                            .isConnected
                                            ? Color(
                                                white:
                                                0.5)
                                            : .blue)
                                }
                            }
                            .padding(
                                .horizontal, 14)
                            .padding(.vertical, 10)
                            .background(
                                recorder.isConnected
                                ? Color(white: 0.15)
                                : Color(
                                    red: 0.1,
                                    green: 0.2,
                                    blue: 0.35))
                            .cornerRadius(10)
                        }
                        .disabled(
                            recorder.isRecording)
                    }

                    // Check cameras
                    Button(action: {
                        recorder.checkCameras()
                    }) {
                        Text(
                            recorder.allCamerasReady
                            ? "Re-check cameras"
                            : "Check cameras")
                            .font(.system(
                                size: 14,
                                weight: .semibold))
                            .foregroundColor(
                                !recorder.isConnected
                                ? Color(white: 0.3)
                                : recorder
                                .allCamerasReady
                                ? .green : .blue)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 11)
                            .background(
                                !recorder.isConnected
                                ? Color(white: 0.08)
                                : recorder
                                .allCamerasReady
                                ? Color(
                                    red: 0.05,
                                    green: 0.2,
                                    blue: 0.05)
                                : Color(
                                    red: 0.1,
                                    green: 0.2,
                                    blue: 0.35))
                            .cornerRadius(10)
                    }
                    .disabled(
                        !recorder.isConnected
                        || recorder.isRecording)

                    // Status banner
                    if recorder.isConnected {
                        HStack(spacing: 8) {
                            Circle()
                                .fill(bannerColor)
                                .frame(
                                    width: 7,
                                    height: 7)
                            Text(bannerText)
                                .font(.system(
                                    size: 12,
                                    weight: .medium))
                                .foregroundColor(
                                    bannerColor)
                            Spacer()
                        }
                        .padding(.horizontal, 12)
                        .padding(.vertical, 8)
                        .background(bannerBg)
                        .cornerRadius(9)
                    }

                    // Cameras
                    HStack {
                        Text("6 CAMERAS — MACBOOK")
                            .font(.system(
                                size: 10,
                                weight: .semibold))
                            .foregroundColor(
                                Color(white: 0.35))
                            .tracking(1)
                        Spacer()
                    }

                    VStack(spacing: 4) {
                        ForEach(
                            0..<6,
                            id: \.self) { i in
                            CameraRowView(
                                id: i + 1,
                                name: camNames[i],
                                position:
                                    camPositions[i],
                                status: recorder
                                    .cameraStatus[i])
                        }
                    }

                    Spacer(minLength: 120)
                }
                .padding(.horizontal, 16)
            }

            // Bottom
            VStack(spacing: 8) {
                Button(action: {
                    if recorder.isRecording {
                        recorder.stopEverything()
                    } else if
                        recorder.allCamerasReady {
                        recorder.startEverything()
                    }
                }) {
                    Text(recordButtonLabel)
                        .font(.system(
                            size: 17,
                            weight: .bold))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 16)
                        .background(
                            recordButtonColor)
                        .cornerRadius(14)
                }
                .disabled(
                    recorder.isStopping ||
                    (!recorder.isRecording
                     && !recorder.allCamerasReady))

                HStack(spacing: 6) {
                    StatCard(
                        value:
                            "\(recorder.frameCount)",
                        label: "Frames",
                        active: recorder.isRecording)
                    StatCard(
                        value:
                            "\(recorder.depthCount)",
                        label: "Depth",
                        active: recorder.isRecording)
                    StatCard(
                        value:
                            "\(recorder.imuCount)",
                        label: "IMU",
                        active: recorder.isRecording)
                    StatCard(
                        value: timeStr(
                            recorder.recordingStart),
                        label: "Time",
                        active: recorder.isRecording)
                }
            }
            .padding(.horizontal, 16)
            .padding(.bottom, 60)
            .padding(.top, 8)
            .background(Color.black)
        }
    }

    var bannerColor: Color {
        if !recorder.camerasChecked { return .blue }
        if recorder.allCamerasReady { return .green }
        return Color(
            red: 0.94, green: 0.63, blue: 0.15)
    }

    var bannerBg: Color {
        if !recorder.camerasChecked {
            return Color(
                red: 0.05, green: 0.1, blue: 0.2)
        }
        if recorder.allCamerasReady {
            return Color(
                red: 0.04, green: 0.12, blue: 0.04)
        }
        return Color(
            red: 0.12, green: 0.09, blue: 0.02)
    }

    var bannerText: String {
        if !recorder.camerasChecked {
            return "MacBook connected — tap Check cameras"
        }
        if recorder.allCamerasReady {
            return "All 6 cameras connected — ready to record"
        }
        let m = recorder.missingCameras
        return "\(m) camera\(m > 1 ? "s" : "") not connected — check USB"
    }

    func timeStr(_ start: Date?) -> String {
        guard let s = start else { return "0:00" }
        let t = Int(Date().timeIntervalSince(s))
        return "\(t/60):\(String(format:"%02d", t%60))"
    }
}

// MARK: - Sessions Screen
struct SessionsView: View {
    @ObservedObject var recorder: BikeRecorder
    @State private var expandedSession: String? = nil
    @State private var verifyResults:
        [String: VerifyResult] = [:]
    @State private var verifying: Set<String> = []

    var grouped: [String: [RecordingSession]] {
        Dictionary(grouping: recorder.sessions) {
            dayLabel($0.startTime) }
    }

    var sortedDays: [String] {
        grouped.keys.sorted { a, b in
            let da =
                grouped[a]?.first?.startTime
                ?? Date()
            let db =
                grouped[b]?.first?.startTime
                ?? Date()
            return da > db
        }
    }

    var body: some View {
        List {
            Section {
                Text("Sessions")
                    .font(.system(
                        size: 22, weight: .bold))
                    .foregroundColor(.white)
                    .listRowBackground(Color.black)
                    .listRowSeparator(.hidden)
                    .padding(.top, 12)
            }

            if recorder.sessions.isEmpty {
                Section {
                    VStack(spacing: 10) {
                        Image(systemName: "tray")
                            .font(.system(size: 40))
                            .foregroundColor(
                                Color(white: 0.25))
                        Text("No recordings yet")
                            .foregroundColor(
                                Color(white: 0.4))
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.top, 60)
                    .listRowBackground(Color.black)
                    .listRowSeparator(.hidden)
                }
            } else {
                ForEach(
                    sortedDays, id: \.self) { day in
                    Section(header:
                        Text(day)
                            .font(.system(
                                size: 11,
                                weight: .semibold))
                            .foregroundColor(
                                Color(white: 0.4))
                            .tracking(0.5)
                    ) {
                        ForEach(
                            grouped[day] ?? [],
                            id: \.id
                        ) { s in
                            SessionCard(
                                session: s,
                                macIP:
                                    recorder.macIP,
                                expanded:
                                    expandedSession
                                    == s.id.uuidString,
                                result:
                                    verifyResults[
                                        s.id
                                        .uuidString],
                                isVerifying:
                                    verifying
                                    .contains(
                                        s.id
                                        .uuidString),
                                onTap: {
                                    withAnimation(
                                        .easeInOut(
                                            duration:
                                            0.2)) {
                                        if expandedSession
                                            == s.id
                                            .uuidString {
                                            expandedSession
                                                = nil
                                        } else {
                                            expandedSession
                                                = s.id
                                                .uuidString
                                            if verifyResults[
                                                s.id
                                                .uuidString]
                                                == nil {
                                                verifySession(s)
                                            }
                                        }
                                    }
                                },
                                onVerify: {
                                    verifySession(s)
                                }
                            )
                            .listRowBackground(
                                Color.black)
                            .listRowSeparator(.hidden)
                            .listRowInsets(
                                EdgeInsets(
                                    top: 3,
                                    leading: 16,
                                    bottom: 3,
                                    trailing: 16))
                            .swipeActions(
                                edge: .trailing,
                                allowsFullSwipe:
                                true) {
                                Button(
                                    role: .destructive
                                ) {
                                    deleteSession(s)
                                } label: {
                                    Label(
                                        "Delete",
                                        systemImage:
                                        "trash")
                                }
                            }
                        }
                    }
                }
            }
        }
        .listStyle(.plain)
        .background(Color.black)
        .scrollContentBackground(.hidden)
    }

    func verifySession(_ s: RecordingSession) {
        let key = s.id.uuidString
        guard !verifying.contains(key)
        else { return }
        verifying.insert(key)

        let conn = NWConnection(
            host: NWEndpoint.Host(recorder.macIP),
            port: NWEndpoint.Port(
                rawValue: 9000)!,
            using: .tcp)
        conn.stateUpdateHandler = { state in
            if case .ready = state {
                let cmd =
                    "VERIFY:\(s.folderPath)"
                conn.send(
                    content: cmd.data(
                        using: .utf8)!,
                    completion: .contentProcessed {
                        _ in
                        conn.receive(
                            minimumIncompleteLength:
                                4,
                            maximumLength: 4
                        ) { data, _, _, _ in
                            guard let data = data,
                                  data.count == 4
                            else {
                                DispatchQueue.main
                                    .async {
                                    self.verifying
                                        .remove(key)
                                }
                                return
                            }
                            let len = Int(UInt32(
                                bigEndian:
                                    data
                                    .withUnsafeBytes {
                                        $0.load(
                                            as: UInt32
                                            .self)
                                    }))
                            conn.receive(
                                minimumIncompleteLength:
                                    1,
                                maximumLength:
                                    max(len, 65536)
                            ) { data, _, _, _ in
                                guard
                                    let data = data,
                                    let json =
                                        try?
                                        JSONSerialization
                                        .jsonObject(
                                            with: data)
                                        as?
                                        [String: Any]
                                else {
                                    DispatchQueue
                                        .main.async {
                                        self
                                        .verifying
                                        .remove(key)
                                    }
                                    return
                                }
                                let result =
                                    VerifyResult(
                                        json: json)
                                DispatchQueue.main
                                    .async {
                                    self
                                    .verifyResults[
                                        key] = result
                                    self.verifying
                                        .remove(key)
                                    conn.cancel()
                                }
                            }
                        }
                    })
            } else if case .failed = state {
                DispatchQueue.main.async {
                    self.verifying.remove(key)
                }
            }
        }
        conn.start(queue: .global())
    }

    func deleteSession(_ s: RecordingSession) {
        withAnimation {
            recorder.sessions.removeAll {
                $0.id == s.id }
            recorder.saveSessions()
            verifyResults.removeValue(
                forKey: s.id.uuidString)
        }
    }

    func dayLabel(_ date: Date) -> String {
        let cal = Calendar.current
        if cal.isDateInToday(date) {
            return "Today — \(fmt(date))"
        } else if cal.isDateInYesterday(date) {
            return "Yesterday — \(fmt(date))"
        }
        return fmt(date)
    }

    func fmt(_ date: Date) -> String {
        let f = DateFormatter()
        f.dateFormat = "d MMM yyyy"
        return f.string(from: date)
    }
}

// MARK: - Session Card
struct SessionCard: View {
    let session:     RecordingSession
    let macIP:       String
    let expanded:    Bool
    let result:      VerifyResult?
    let isVerifying: Bool
    let onTap:       () -> Void
    let onVerify:    () -> Void

    @State private var copied = false

    var isWarning: Bool {
        session.name.contains("⚠️")
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {

            Button(action: onTap) {
                HStack(spacing: 10) {
                    ZStack {
                        Circle()
                            .fill(headerDotBg)
                            .frame(
                                width: 28,
                                height: 28)
                        if isVerifying {
                            ProgressView()
                                .scaleEffect(0.6)
                                .tint(.white)
                        } else if let r = result {
                            Image(systemName:
                                r.healthy
                                ? "checkmark"
                                : "exclamationmark")
                                .font(.system(
                                    size: 12,
                                    weight: .bold))
                                .foregroundColor(
                                    r.healthy
                                    ? .green
                                    : .orange)
                        } else {
                            Image(systemName:
                                isWarning
                                ? "exclamationmark.triangle"
                                : "questionmark")
                                .font(.system(
                                    size: 11))
                                .foregroundColor(
                                    isWarning
                                    ? .orange
                                    : Color(
                                        white: 0.4))
                        }
                    }

                    VStack(alignment: .leading,
                           spacing: 3) {
                        Text(session.name)
                            .font(.system(
                                size: 14,
                                weight: .semibold))
                            .foregroundColor(
                                isWarning
                                ? .orange : .white)
                        HStack(spacing: 8) {
                            Label(
                                durStr(
                                    session.duration),
                                systemImage: "clock")
                            Label(
                                "\(session.cameraCount) cams",
                                systemImage: "video")
                            Label(
                                "\(session.depthFrames) depth",
                                systemImage: "cube")
                        }
                        .font(.system(size: 10))
                        .foregroundColor(
                            Color(white: 0.4))
                    }

                    Spacer()

                    VStack(alignment: .trailing,
                           spacing: 3) {
                        Text(timeOfDay(
                            session.startTime))
                            .font(.system(size: 11))
                            .foregroundColor(
                                Color(white: 0.35))
                        Image(systemName:
                            expanded
                            ? "chevron.up"
                            : "chevron.down")
                            .font(.system(size: 10))
                            .foregroundColor(
                                Color(white: 0.3))
                    }
                }
                .padding(12)
            }

            if expanded {
                Divider()
                    .background(Color(white: 0.12))

                VStack(alignment: .leading,
                       spacing: 12) {

                    HStack(spacing: 6) {
                        Image(systemName:
                            copied
                            ? "checkmark"
                            : "doc.on.doc")
                            .font(.system(size: 10))
                            .foregroundColor(
                                copied
                                ? .green : .blue)
                        Text(session.folderPath)
                            .font(.system(
                                size: 10,
                                design: .monospaced))
                            .foregroundColor(
                                copied
                                ? .green : .blue)
                            .lineLimit(1)
                            .truncationMode(.middle)
                        Spacer()
                    }
                    .onTapGesture {
                        UIPasteboard.general
                            .string =
                            session.folderPath
                        copied = true
                        DispatchQueue.main
                            .asyncAfter(
                            deadline: .now() + 2) {
                            copied = false
                        }
                    }

                    if isVerifying {
                        HStack {
                            ProgressView()
                                .scaleEffect(0.8)
                            Text("Checking files...")
                                .font(
                                    .system(size: 12))
                                .foregroundColor(
                                    Color(white: 0.4))
                        }
                    } else if let r = result {
                        VStack(
                            alignment: .leading,
                            spacing: 4) {
                            SectionHeader(
                                text: "CAMERA FILES")
                            ForEach(
                                r.cameras,
                                id: \.name) { cam in
                                FileRow(
                                    icon:
                                        "video.fill",
                                    name: cam.name,
                                    detail: sizeStr(
                                        cam.size),
                                    status: cam.ok
                                    ? .ok : .corrupt)
                            }
                            if r.cameras.isEmpty {
                                Text(
                                    "No camera files found")
                                    .font(.system(
                                        size: 11))
                                    .foregroundColor(
                                        .orange)
                            }
                        }

                        VStack(
                            alignment: .leading,
                            spacing: 4) {
                            SectionHeader(
                                text: "SENSOR DATA")
                            FileRow(
                                icon: "cube.fill",
                                name: "depth/",
                                detail:
                                    "\(r.depth) frames",
                                status: r.depth > 0
                                ? .ok : .missing)
                            FileRow(
                                icon: "waveform",
                                name: "imu.csv",
                                detail:
                                    "\(r.imu) rows",
                                status: r.imu > 0
                                ? .ok : .missing)
                            FileRow(
                                icon:
                                    "location.fill",
                                name: "gps.csv",
                                detail:
                                    "\(r.gps) points",
                                status: r.gps > 0
                                ? .ok : .missing)
                        }

                        HStack(spacing: 6) {
                            Image(systemName:
                                r.healthy
                                ? "checkmark.circle.fill"
                                : "exclamationmark.circle.fill")
                                .foregroundColor(
                                    r.healthy
                                    ? .green
                                    : .orange)
                            Text(r.healthy
                                 ? "All files OK"
                                 : "Some files have issues")
                                .font(.system(
                                    size: 12,
                                    weight: .medium))
                                .foregroundColor(
                                    r.healthy
                                    ? .green
                                    : .orange)
                            Spacer()
                            Button(
                                action: onVerify) {
                                Text("Re-check")
                                    .font(.system(
                                        size: 11))
                                    .foregroundColor(
                                        .blue)
                            }
                        }
                        .padding(8)
                        .background(
                            r.healthy
                            ? Color(
                                red: 0.04,
                                green: 0.12,
                                blue: 0.04)
                            : Color(
                                red: 0.12,
                                green: 0.08,
                                blue: 0.02))
                        .cornerRadius(8)

                    } else {
                        Button(action: onVerify) {
                            HStack(spacing: 6) {
                                Image(systemName:
                                    "magnifyingglass")
                                    .font(.system(
                                        size: 12))
                                Text("Check files")
                                    .font(.system(
                                        size: 13,
                                        weight:
                                        .medium))
                            }
                            .foregroundColor(.blue)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 10)
                            .background(Color(
                                red: 0.05,
                                green: 0.1,
                                blue: 0.2))
                            .cornerRadius(8)
                        }
                    }
                }
                .padding(12)
            }
        }
        .background(
            isWarning
            ? Color(
                red: 0.1,
                green: 0.07,
                blue: 0.0)
            : Color(white: 0.07))
        .cornerRadius(12)
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(
                    borderColor,
                    lineWidth: 0.5))
    }

    var headerDotBg: Color {
        if isWarning {
            return Color.orange.opacity(0.2) }
        if let r = result {
            return r.healthy
                ? Color.green.opacity(0.15)
                : Color.orange.opacity(0.15)
        }
        return Color(white: 0.12)
    }

    var borderColor: Color {
        if isWarning {
            return Color.orange.opacity(0.35) }
        if let r = result {
            return r.healthy
                ? Color.green.opacity(0.2)
                : Color.orange.opacity(0.25)
        }
        return Color(white: 0.13)
    }

    func timeOfDay(_ d: Date) -> String {
        let f = DateFormatter()
        f.dateFormat = "h:mm a"
        return f.string(from: d)
    }

    func durStr(_ t: TimeInterval) -> String {
        let m = Int(t) / 60
        let s = Int(t) % 60
        return "\(m):\(String(format:"%02d", s))"
    }

    func sizeStr(_ bytes: Int) -> String {
        if bytes > 1_000_000_000 {
            return String(
                format: "%.1f GB",
                Double(bytes) / 1_000_000_000)
        } else if bytes > 1_000_000 {
            return String(
                format: "%.1f MB",
                Double(bytes) / 1_000_000)
        } else {
            return String(
                format: "%.0f KB",
                Double(bytes) / 1000)
        }
    }
}

// MARK: - File Row
enum FileStatus { case ok, corrupt, missing }

struct FileRow: View {
    let icon:   String
    let name:   String
    let detail: String
    let status: FileStatus

    var statusIcon: String {
        switch status {
        case .ok:
            return "checkmark.circle.fill"
        case .corrupt:
            return "xmark.circle.fill"
        case .missing:
            return "minus.circle.fill"
        }
    }

    var statusColor: Color {
        switch status {
        case .ok:      return .green
        case .corrupt: return .red
        case .missing: return .orange
        }
    }

    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: statusIcon)
                .font(.system(size: 11))
                .foregroundColor(statusColor)
                .frame(width: 16)
            Image(systemName: icon)
                .font(.system(size: 10))
                .foregroundColor(Color(white: 0.4))
                .frame(width: 14)
            Text(name)
                .font(.system(
                    size: 12,
                    design: .monospaced))
                .foregroundColor(Color(white: 0.75))
            Spacer()
            Text(detail)
                .font(.system(size: 11))
                .foregroundColor(
                    statusColor.opacity(0.8))
        }
        .padding(.vertical, 3)
        .padding(.horizontal, 6)
        .background(
            status == .ok
            ? Color.clear
            : statusColor.opacity(0.05))
        .cornerRadius(5)
    }
}

struct SectionHeader: View {
    let text: String
    var body: some View {
        Text(text)
            .font(.system(
                size: 9, weight: .semibold))
            .foregroundColor(Color(white: 0.3))
            .tracking(1)
            .padding(.top, 4)
            .padding(.bottom, 2)
    }
}

// MARK: - Data Models
struct VerifyResult {
    let cameras: [CamFile]
    let depth:   Int
    let imu:     Int
    let gps:     Int
    let healthy: Bool

    init(json: [String: Any]) {
        let cams =
            json["cameras"]
            as? [[String: Any]] ?? []
        cameras = cams.map {
            CamFile(
                name: $0["name"]
                    as? String ?? "",
                size: $0["size"]
                    as? Int    ?? 0,
                ok:   $0["ok"]
                    as? Bool   ?? false)
        }
        depth   = json["depth"]   as? Int  ?? 0
        imu     = json["imu"]     as? Int  ?? 0
        gps     = json["gps"]     as? Int  ?? 0
        healthy =
            json["healthy"] as? Bool ?? false
    }
}

struct CamFile {
    let name: String
    let size: Int
    let ok:   Bool
}

// MARK: - Status Badge
struct StatusBadge: View {
    @ObservedObject var recorder: BikeRecorder
    var body: some View {
        HStack(spacing: 5) {
            if recorder.isConnecting {
                ProgressView()
                    .scaleEffect(0.6)
                    .tint(Color(white: 0.5))
            } else {
                Circle()
                    .fill(badgeColor)
                    .frame(width: 7, height: 7)
            }
            Text(badgeText)
                .font(.system(
                    size: 11, weight: .medium))
                .foregroundColor(badgeColor)
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 5)
        .background(Color(white: 0.1))
        .cornerRadius(12)
    }

    var badgeColor: Color {
        if recorder.isConnecting {
            return Color(white: 0.4) }
        if recorder.isRecording  { return .red }
        if recorder.allCamerasReady {
            return .green }
        if recorder.isConnected  { return .blue }
        return Color(white: 0.35)
    }

    var badgeText: String {
        if recorder.isConnecting {
            return "Connecting..." }
        if recorder.isRecording {
            return "Recording" }
        if recorder.allCamerasReady {
            return "Ready" }
        if recorder.isConnected {
            return "Connected" }
        return "Offline"
    }
}

// MARK: - Camera Row
struct CameraRowView: View {
    let id: Int
    let name: String
    let position: String
    let status: String?

    var statusLabel: String {
        switch status {
        case "recording":    return "Recording"
        case "connected":    return "Connected"
        case "disconnected": return "Not connected"
        case "crashed":      return "Disconnected!"
        default:             return "Not connected"
        }
    }

    var dotColor: Color {
        switch status {
        case "recording":    return .red
        case "connected":    return .green
        case "disconnected":
            return Color(white: 0.3)
        case "crashed":      return .red
        default:             return Color(white: 0.2)
        }
    }

    var bgColor: Color {
        switch status {
        case "recording":
            return Color(
                red: 0.12, green: 0.03, blue: 0.03)
        case "crashed":
            return Color(
                red: 0.18, green: 0.03, blue: 0.03)
        default:
            return Color(white: 0.07)
        }
    }

    var borderCol: Color {
        switch status {
        case "recording":
            return Color.red.opacity(0.25)
        case "connected":
            return Color.green.opacity(0.2)
        case "crashed":
            return Color.red.opacity(0.6)
        default:
            return Color(white: 0.11)
        }
    }

    var body: some View {
        HStack {
            Text("\(id)")
                .font(.system(
                    size: 11, weight: .bold))
                .foregroundColor(.white)
                .frame(width: 26, height: 26)
                .background(
                    status == "recording"
                    || status == "crashed"
                    ? Color.red.opacity(0.25)
                    : status == "connected"
                    ? Color.green.opacity(0.15)
                    : Color(white: 0.12))
                .cornerRadius(6)

            VStack(alignment: .leading, spacing: 1) {
                Text(name)
                    .font(.system(
                        size: 13, weight: .semibold))
                    .foregroundColor(
                        status == "crashed"
                        ? .red : .white)
                Text(position)
                    .font(.system(size: 10))
                    .foregroundColor(
                        Color(white: 0.4))
            }

            Spacer()

            HStack(spacing: 4) {
                if status == "crashed" {
                    Image(systemName:
                        "exclamationmark.triangle.fill")
                        .font(.system(size: 10))
                        .foregroundColor(.red)
                }
                Circle()
                    .fill(dotColor)
                    .frame(width: 6, height: 6)
                Text(statusLabel)
                    .font(.system(
                        size: 11, weight: .medium))
                    .foregroundColor(dotColor)
            }
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 8)
        .background(bgColor)
        .cornerRadius(10)
        .overlay(
            RoundedRectangle(cornerRadius: 10)
                .stroke(
                    borderCol,
                    lineWidth:
                        status == "crashed"
                        ? 1.0 : 0.5))
    }
}

// MARK: - Sensor Card
struct SensorCard: View {
    let name: String
    let value: String
    let color: Color
    var body: some View {
        VStack(alignment: .leading, spacing: 3) {
            Text(name)
                .font(.system(
                    size: 8, weight: .semibold))
                .foregroundColor(Color(white: 0.35))
                .tracking(0.3)
            Text(value)
                .font(.system(
                    size: 11, weight: .bold))
                .foregroundColor(color)
                .lineLimit(1)
                .minimumScaleFactor(0.7)
        }
        .frame(
            maxWidth: .infinity,
            alignment: .leading)
        .padding(7)
        .background(Color(white: 0.08))
        .cornerRadius(8)
        .overlay(
            RoundedRectangle(cornerRadius: 8)
                .stroke(
                    Color(white: 0.14),
                    lineWidth: 0.5))
    }
}

// MARK: - Stat Card
struct StatCard: View {
    let value:  String
    let label:  String
    let active: Bool
    var body: some View {
        VStack(spacing: 2) {
            Text(value)
                .font(.system(
                    size: 15, weight: .bold))
                .foregroundColor(
                    active ? .white
                    : Color(white: 0.25))
            Text(label)
                .font(.system(
                    size: 8, weight: .semibold))
                .foregroundColor(Color(white: 0.3))
                .tracking(0.5)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 8)
        .background(Color(white: 0.08))
        .cornerRadius(8)
    }
}
