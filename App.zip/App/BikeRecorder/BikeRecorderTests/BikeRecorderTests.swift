//
//  BikeRecorderTests.swift
//  BikeRecorderTests
//
//  Created by smlab on 3/27/26.
//

import Testing

struct BikeRecorderTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
        // Swift Testing Documentation
        // https://developer.apple.com/documentation/testing
    }

}
